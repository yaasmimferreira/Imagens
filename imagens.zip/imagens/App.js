import {StyleSheet,View,Image,TouchableOpacity,Text, SafeAreaView,Alert,ScrollView} from 'react-native';
//import { SafeAreaView } from 'react-native-safe-area-context';

function App() {
  function corrida() {
    Alert.alert('Titulo','Atividade Física Corrida');
  }
  function musculacao() {
    Alert.alert('Titulo', 'Atividade Física Musculação');
  }
  function bicicleta() {
    Alert.alert('Titulo', 'Atividade Física Bicicleta');
  }
  function natacao() {
    Alert.alert('Titulo', 'Atividade Física Natação');
  }
  function luta() {
    Alert.alert('Titulo', 'Atividade Física Luta');
  }

  return (
    <SafeAreaView style={estilo.container}>
     <ScrollView>
      <View>
        <Text style={estilo.text}>Exercícios Físicos :</Text>
      </View>

      <View>
        <Image style={estilo.img} source={require('./assets/corrida.jpg')} />
      </View>
      <View>
        <TouchableOpacity style={estilo.botao} onPress={corrida}>
          <Text style={estilo.texto}> Clique Aqui</Text>
        </TouchableOpacity> 
      </View>

      <View>
        <Image style={estilo.img} source={require('./assets/academia.jpg')} />
      </View>
      <View>
         <TouchableOpacity style={estilo.botao} onPress={musculacao}>
          <Text style={estilo.texto}> Clique Aqui</Text>
        </TouchableOpacity>
      </View>

      <View>
        <Image style={estilo.img} source={require('./assets/bicicleta.jpg')} /> 
      </View>
      <View>
        <TouchableOpacity style={estilo.botao} onPress={bicicleta}>
          <Text style={estilo.texto}> Clique Aqui</Text>
        </TouchableOpacity>      
      </View>

      <View>
        <Image style={estilo.img} source={require('./assets/natacao1.jpg')} />
      </View>
      <View>
        <TouchableOpacity style={estilo.botao} onPress={natacao}>
          <Text style={estilo.texto}> Clique Aqui</Text>
        </TouchableOpacity>      
      </View>

      <View>
        <Image style={estilo.img} source={require('./assets/luta.jpg')} />
      </View>
      <View>
        <TouchableOpacity style={estilo.botao} onPress={luta}>
          <Text style={estilo.texto}> Clique Aqui</Text>
        </TouchableOpacity>
      </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const estilo = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#acbef0cc',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 8,
  },
  img: {
    width: 150,
    height: 100,
    alignItems: 'center',
    marginBottom: 20,
    marginTop: 20,
    margin: 10,
    borderWidth: 0.5,
    justifyContent: 'center',
  },

  botao: {
    backgroundColor: '#f7b251',
    borderRadius: 10,
    alignItems: 'center',
    height: 30,
    justifyContent: 'center',
  },

  text: {
    fontSize: 20,
    color: 'ecf0f1',
  },
});

export default App;
